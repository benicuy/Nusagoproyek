# NusaGo

Prototipe aplikasi pemesanan ojek motor, mobil, dan makanan.
Web ada di `www/index.html`, dibungkus Capacitor untuk Android.

## Cara pakai
1. Upload folder ini ke repo GitHub (branch `main`).
2. Buka tab **Actions**, jalankan workflow **Build APK**, atau tunggu sampai ada push.
3. Setelah selesai, unduh artifact `nusago-debug-apk` dan pasang APK-nya di HP Android.

## Lokal (opsional)
```
npm install
npx cap add android
npx cap sync android
```
